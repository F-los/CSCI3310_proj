package edu.cuhk3310.myapplication;

public class music_info {

    String url;
    String music_name;
    String singer;
    int rating;
    int play_num;

    public music_info(String url, String music_name, String singer, int rating, int play_num){
        this.url = url;
        this.music_name =music_name;
        this.singer = singer;
        this.rating = rating;
        this.play_num = play_num;
    }
    public String getUrl(){
        return getUrl();
    }
    public void setUrl(String url){
        this.url = url;
    }

    public String getMusic_name(){
        return music_name;
    }
    public void setMusic_name(String music_name){
        this.music_name = music_name;
    }

    public String getSinger(){
        return singer;
    }
    public void setSinger(String singer){
        this.singer = singer;
    }

    public Integer getRating(){
        return rating;
    }
    public void setRating(Integer rating){
        this.rating = rating;
    }
    public int getPlay_num(){
        return play_num;
    }
    public void setRichness(int play_num){
        this.play_num = play_num;
    }

}
