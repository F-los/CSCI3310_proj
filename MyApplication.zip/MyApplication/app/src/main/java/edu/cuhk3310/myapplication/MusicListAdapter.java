package edu.cuhk3310.myapplication;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;

import java.util.LinkedList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MusicListAdapter extends RecyclerView.Adapter<MusicListAdapter.MusicViewHolder> {
    private Context mcon;
    private LayoutInflater mInflater;
    private final LinkedList<String> mImagePathList;
//    private final LinkedList<flower_info> mImagePathList;
    class MusicViewHolder extends RecyclerView.ViewHolder {

        ImageView flowerImageItemView;
        RatingBar flowerRichnessBar;

        final MusicListAdapter mAdapter;

        public MusicViewHolder(View itemView, MusicListAdapter adapter) {
            super(itemView);
//            flowerImageItemView = itemView.findViewById(R.id.image);
//            flowerRichnessBar = itemView.findViewById(R.id.flowerBar);
            this.mAdapter = adapter;

            // Event handling registration, page navigation goes here
            // Event handling registration, page navigation goes here
//            flowerImageItemView.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    // Get the position of the item that was clicked.
//                    int position = getLayoutPosition();
//
////                    Intent intent = new Intent(mcon, DetailActivity.class);
////                    intent.putExtra("flowername", mImagePathList.get(position).getFlowername());
////                    intent.putExtra("imgfile", mImagePathList.get(position).getFilename());
////                    intent.putExtra("genus", mImagePathList.get(position).getGenus());
////                    intent.putExtra("richness", mImagePathList.get(position).getRichness());
////                    ((Activity)mcon).startActivityForResult(intent, REQUEST_CODE);
//                }
//            });

            // End of ViewHolder initialization
        }
    }

    public MusicListAdapter(Context context,
                            LinkedList<String> imagePathList) {
        mcon = context;
        mInflater = LayoutInflater.from(context);
        this.mImagePathList = imagePathList;

    }

    @NonNull
    @Override
    public MusicViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View mItemView = mInflater.inflate(R.layout.fragment_item, parent, false);
        return new MusicViewHolder(mItemView, this);
    }

    @Override
    public void onBindViewHolder(@NonNull MusicViewHolder holder, int position) {
        String mImagePath = mImagePathList.get(position);
        Uri uri = Uri.parse(mImagePath);
//         Update the following to display correct information based on the given position
//
//
//         Set up View items for this row (position), modify to show correct information read from the CSV
        holder.flowerImageItemView.setImageURI(uri);
        holder.flowerRichnessBar.setRating(3.0f);

    }

    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        return mImagePathList.size();
    }

}





