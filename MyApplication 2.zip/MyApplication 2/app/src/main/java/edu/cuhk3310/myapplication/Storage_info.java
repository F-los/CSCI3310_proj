package edu.cuhk3310.myapplication;

public class Storage_info {
    String name;
    int id;

    public Storage_info(String name, int id){
        this.name = name;
        this.id = id;

    }
    public String getName(){
        return getName();
    }
    public void setName(String name){
        this.name = name;
    }

    public String getId(){
        return getId();
    }
    public void setId(int id){
        this.id = id;
    }
}
