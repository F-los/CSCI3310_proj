package edu.cuhk3310.myapplication;

public class MusicItem {
    public MusicItem(int a_imageResId, String music_name, int rating, int play_num) {
        mImageResId = a_imageResId;
        musicname = music_name;
        this.rating = rating;
        this.play_num = play_num;
    }

    private int mImageResId;

    private String musicname;
    private int rating;
    private int play_num;
    public void setImageResId(int a_imageResId) {
        mImageResId = a_imageResId;
    }

    public int getImageResId() {
        return mImageResId;
    }

    public void setMusicname(String music_name) {
        musicname = music_name;
    }

    public String getMusicname() {
        return musicname;
    }

    public void setRating(int rating) {this.rating = rating; }
    public int getRating() {return this.rating ;}

    public void setPlay_num(int play_num) { this.play_num = play_num; }
    public int getPlay_num() { return this.play_num ; }
}
