package edu.cuhk3310.myapplication;

import static android.content.ContentValues.TAG;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class PlayListActivity extends AppCompatActivity {

    // List item
    private List<PlayListItem> mItemList;

    // List view
    private ListView mListView;
    Button btn1,btn2, btn3;
    // ListView adapter
    private PlayListArrayAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_playlist);

        // List 설정
        mItemList = getStringArrayPref(getApplicationContext(), "1");
        bindList();
        btn3 = (Button) findViewById(R.id.btn3);
        // 삽입 설정

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Item 추가
                AlertDialog.Builder ad = new AlertDialog.Builder(PlayListActivity.this);
                ad.setIcon(R.mipmap.ic_launcher);
                ad.setTitle("Add new playlist");
                final EditText et = new EditText(PlayListActivity.this);
                ad.setView(et);
                ad.setPositiveButton("Add", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String result = et.getText().toString();

                        mItemList.add(new PlayListItem(R.drawable.ic_launcher_background, result ));

                        // List 반영
                        mAdapter.notifyDataSetChanged();
                        dialogInterface.dismiss();
                    }
                });

                ad.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String result = et.getText().toString();
                        dialogInterface.dismiss();
                    }
                });
                ad.show();

            }
        });
//
//        // 수정 설정
//        bindModify();
//
//        // 삭제 설정
//        bindDelete();
    }

    /**
     * List 설정
     */
    private void bindList() {

        mAdapter = new PlayListArrayAdapter(this, mItemList);

        mListView = (ListView) findViewById(R.id.listview);
        mListView.setAdapter(mAdapter);

        // List item click event 처리
        mListView.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> a_parent, View a_view, int a_position, long a_id) {
                final PlayListItem item = (PlayListItem) mAdapter.getItem(a_position);
                Toast.makeText(PlayListActivity.this, item.getMusicname() + " selected", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(), ListActivity.class);
                intent.putExtra("list_num", item.getMusicname() );
                startActivity(intent);
            }
        });
    }
    private void setStringArrayPref(Context context, String key, List<PlayListItem> values) {

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = prefs.edit();
        JSONArray a = new JSONArray();

        for (int i = 0; i < values.size(); i++) {
            a.put(values.get(i).getMusicname());
        }

        if (!values.isEmpty()) {
            editor.putString(key, a.toString());
        } else {
            editor.putString(key, null);
        }

        editor.apply();
    }

    private List getStringArrayPref(Context context, String key) {

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        String json = prefs.getString(key, null);
        List<PlayListItem> urls = new ArrayList<>();

        if (json != null) {
            try {
                JSONArray a = new JSONArray(json);
                for (int i = 0; i < a.length(); i++) {
                    String url = a.optString(i);
                    PlayListItem fa = new PlayListItem(R.drawable.ic_launcher_background,url);
                    System.out.println(url+"!!!!!");

                    urls.add(fa);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return urls;
    }

    @Override
    protected void onPause() {
        super.onPause();

        setStringArrayPref(getApplicationContext(), "1", mItemList);
        Log.d(TAG, "Put json");
    }




    /**
     * 삽입 설정
     */
//    private void bindInsert() {
//        findViewById(R.id.btn3.setOnClickListener(new OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                // Item 추가
//                mItemList.add(new PlayListItem(R.drawable.ic_launcher_background, "Korea " + mItemList.size()));
//
//                // List 반영
//                mCountryAdapter.notifyDataSetChanged();
//            }
//        });
//    }

    /**
     * 수정 설정
     */
//    private void bindModify() {
//        findViewById(R.id.btn_modify).setOnClickListener(new OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                final int position = mListView.getCheckedItemPosition();
//                if (position == -1) {
//                    Toast.makeText(PhMainActivity.this, R.string.err_no_selected_item, Toast.LENGTH_SHORT).show();
//                    return;
//                }
//
//                // List item 수정
//                PhCountryItem countryItem = mItemList.get(position);
//                countryItem.setCountry(countryItem.getCountry() + " is modified");
//
//                // List 반영
//                mCountryAdapter.notifyDataSetChanged();
//            }
//        });
//    }

    /**
     * 삭제 설정
     */
//    private void bindDelete() {
//        findViewById(R.id.btn_delete).setOnClickListener(new OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                final int position = mListView.getCheckedItemPosition();
//                if (position == -1) {
//                    Toast.makeText(PhMainActivity.this, R.string.err_no_selected_item, Toast.LENGTH_SHORT).show();
//                    return;
//                }
//
//                // 선택한 list item 삭제
//                mItemList.remove(position);
//
//                // 선택 항목 초기화
//                mListView.setItemChecked(-1, true);
//
//                // List 반영
//                mCountryAdapter.notifyDataSetChanged();
//            }
//        });
//    }
}