package edu.cuhk3310.myapplication;

import static android.content.ContentValues.TAG;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class AddMusicActivity extends AppCompatActivity {

    // List item
    private List<PlayListItem> mItemList;

    // List view
    private ListView mListView;
    // ListView adapter

    private PlayListArrayAdapter mAdapter;

    String musicName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_music);

        Intent intent = getIntent();
        musicName = intent.getStringExtra("MUSIC_NAME");

        // List 설정
        mItemList = getStringArrayPref(getApplicationContext(), "1");
        bindList();
    }

    /**
     * List 설정
     */
    private void bindList() {

        mAdapter = new PlayListArrayAdapter(this, mItemList);

        mListView = (ListView) findViewById(R.id.listview);
        mListView.setAdapter(mAdapter);

        // List item click event 처리
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(view.getContext(), MusicPlayerActivity.class);
                intent.putExtra("MUSIC_NAME", musicName);
                startActivity(intent);
            }
        });

    }
    private void setStringArrayPref(Context context, String key, List<PlayListItem> values) {

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = prefs.edit();
        JSONArray a = new JSONArray();

        for (int i = 0; i < values.size(); i++) {
            a.put(values.get(i).getMusicname());
        }

        if (!values.isEmpty()) {
            editor.putString(key, a.toString());
        } else {
            editor.putString(key, null);
        }

        editor.apply();
    }

    private List getStringArrayPref(Context context, String key) {

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        String json = prefs.getString(key, null);
        List<PlayListItem> urls = new ArrayList<>();

        if (json != null) {
            try {
                JSONArray a = new JSONArray(json);
                for (int i = 0; i < a.length(); i++) {
                    String url = a.optString(i);
                    PlayListItem fa = new PlayListItem(R.drawable.ic_launcher_background,url);
                    System.out.println(url+"!!!!!");

                    urls.add(fa);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return urls;
    }

    @Override
    protected void onPause() {
        super.onPause();

        setStringArrayPref(getApplicationContext(), "1", mItemList);
        Log.d(TAG, "Put json");
    }




    /**
     * 삽입 설정
     */
//    private void bindInsert() {
//        findViewById(R.id.btn3.setOnClickListener(new OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                // Item 추가
//                mItemList.add(new PlayListItem(R.drawable.ic_launcher_background, "Korea " + mItemList.size()));
//
//                // List 반영
//                mCountryAdapter.notifyDataSetChanged();
//            }
//        });
//    }

    /**
     * 수정 설정
     */
//    private void bindModify() {
//        findViewById(R.id.btn_modify).setOnClickListener(new OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                final int position = mListView.getCheckedItemPosition();
//                if (position == -1) {
//                    Toast.makeText(PhMainActivity.this, R.string.err_no_selected_item, Toast.LENGTH_SHORT).show();
//                    return;
//                }
//
//                // List item 수정
//                PhCountryItem countryItem = mItemList.get(position);
//                countryItem.setCountry(countryItem.getCountry() + " is modified");
//
//                // List 반영
//                mCountryAdapter.notifyDataSetChanged();
//            }
//        });
//    }

    /**
     * 삭제 설정
     */
//    private void bindDelete() {
//        findViewById(R.id.btn_delete).setOnClickListener(new OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                final int position = mListView.getCheckedItemPosition();
//                if (position == -1) {
//                    Toast.makeText(PhMainActivity.this, R.string.err_no_selected_item, Toast.LENGTH_SHORT).show();
//                    return;
//                }
//
//                // 선택한 list item 삭제
//                mItemList.remove(position);
//
//                // 선택 항목 초기화
//                mListView.setItemChecked(-1, true);
//
//                // List 반영
//                mCountryAdapter.notifyDataSetChanged();
//            }
//        });
//    }
}