package edu.cuhk3310.myapplication;

import static android.content.ContentValues.TAG;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class AddMusicActivity extends AppCompatActivity {

    // List item
    private List<PlayListItem> mItemList;

    // List view
    private ListView mListView;
    // ListView adapter

    private PlayListArrayAdapter mAdapter;

    String musicName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_music);

        Intent intent = getIntent();
        musicName = intent.getStringExtra("MUSIC_NAME");

        // List 설정
        mItemList = getStringArrayPref(getApplicationContext(), "1");
        bindList();
    }

    /**
     * List 설정
     */
    private void bindList() {

        mAdapter = new PlayListArrayAdapter(this, mItemList);

        mListView = (ListView) findViewById(R.id.listview);
        mListView.setAdapter(mAdapter);

        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String musicKey = mItemList.get(position).getMusicname();
                List<String> musicList = getMusicList(getApplicationContext(), musicKey);

                // Add the new music to the list
                musicList.add(musicName);

                // Save the updated list back to SharedPreferences
                saveMusicList(getApplicationContext(), musicKey, musicList);

                Intent intent = new Intent(view.getContext(), MusicPlayerActivity.class);
                intent.putExtra("MUSIC_NAME", musicName);
                startActivity(intent);
            }
        });


    }

    private void setStringArrayPref(Context context, String key, List<PlayListItem> values) {

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = prefs.edit();
        JSONArray a = new JSONArray();

        for (int i = 0; i < values.size(); i++) {
            a.put(values.get(i).getMusicname());
        }

        if (!values.isEmpty()) {
            editor.putString(key, a.toString());
        } else {
            editor.putString(key, null);
        }

        editor.apply();
    }

    private List getStringArrayPref(Context context, String key) {

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        String json = prefs.getString(key, null);
        List<PlayListItem> urls = new ArrayList<>();

        if (json != null) {
            try {
                JSONArray a = new JSONArray(json);
                for (int i = 0; i < a.length(); i++) {
                    String url = a.optString(i);
                    PlayListItem fa = new PlayListItem(R.drawable.ic_launcher_background, url);
                    System.out.println(url + "!!!!!");

                    urls.add(fa);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return urls;
    }

    @Override
    protected void onPause() {
        super.onPause();

        setStringArrayPref(getApplicationContext(), "1", mItemList);
        Log.d(TAG, "Put json");
    }

    // Use this method to save the music list as a JSON string in SharedPreferences
    private void saveMusicList(Context context, String key, List<String> musicList) {
        SharedPreferences sharedPref = context.getSharedPreferences("tempStorage", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();

        JSONArray jsonArray = new JSONArray();
        for (String music : musicList) {
            jsonArray.put(music);
        }
        editor.putString(key, jsonArray.toString());
        editor.apply();
    }

    // Use this method to retrieve the music list from SharedPreferences and convert the JSON string to an ArrayList
    private List<String> getMusicList(Context context, String key) {
        SharedPreferences sharedPref = context.getSharedPreferences("tempStorage", Context.MODE_PRIVATE);
        String jsonString = sharedPref.getString(key, null);

        List<String> musicList = new ArrayList<>();
        if (jsonString != null) {
            try {
                JSONArray jsonArray = new JSONArray(jsonString);
                for (int i = 0; i < jsonArray.length(); i++) {
                    musicList.add(jsonArray.getString(i));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return musicList;
    }
}