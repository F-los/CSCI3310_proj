package edu.cuhk3310.myapplication;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class PlayListItemViewHolder {

    public ImageView ivIcon;

    public TextView musicName;

    public PlayListItemViewHolder(View a_view) {
        ivIcon = a_view.findViewById(R.id.iv_icon);
        musicName = a_view.findViewById(R.id.tv_country);
    }
}