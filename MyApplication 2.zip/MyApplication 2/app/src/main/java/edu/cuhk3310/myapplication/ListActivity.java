package edu.cuhk3310.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

public class ListActivity extends AppCompatActivity {
    String list_num;
    private ListView mListView;
    private ListAdapter mAdapter;

    String json;
    private List<MusicItem> mItemList, sortedList, resList;
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        Intent intent = getIntent();
        list_num = intent.getStringExtra("list_num");
        System.out.println("!!!!!" + list_num);

//        mItemList = getStringArrayPref(getApplicationContext(), "1");
        bindList();


        System.out.println(mItemList);


    }
    private List<MusicItem> sortList(List<MusicItem> list) {
        List<MusicItem> sortedList = new ArrayList<>(list);
        Collections.sort(sortedList, new Comparator<MusicItem>() {
            @Override
            public int compare(MusicItem o1, MusicItem o2) {
                int result = Integer.compare(o2.getPlay_num(), o1.getPlay_num());
                // sort by play_num in descending order
                if (result == 0) {
                    result = Integer.compare(o2.getRating(), o1.getRating()); // if play_num is the same, sort by rating in descending order
                }
                return result;
            }
        });
        return sortedList;
    }

    private void bindList() {
        sortedList = new ArrayList<>();
        mItemList = new ArrayList<>();
        resList = new ArrayList<>();
        InputStream XmlFileInputStream = getResources().openRawResource(R.raw.storage);
        json = readTextFile(XmlFileInputStream);
        try{
            JSONObject jsonObject = new JSONObject(json);
            JSONArray playlistArr = jsonObject.getJSONArray("storages");
            for (int i = 0 ; i< playlistArr.length(); i++){
                JSONObject listObj = playlistArr.getJSONObject(i);
                String list_num1 = listObj.getString("list_num");

                if (list_num.equals(list_num1)){
                    JSONArray jsonArray = listObj.getJSONArray("musics");

                    for (int j = 0; j < jsonArray.length(); j++){
                        JSONObject musicObj = jsonArray.getJSONObject(j);
                        String url = musicObj.getString("url");
                        String music_name = musicObj.getString("music_name");
                        int rating = musicObj.getInt("rating");
                        int play_num = musicObj.getInt("play_num");
                        mItemList.add(new MusicItem(R.drawable.ic_launcher_background, music_name, rating, play_num));

                    }


                    sortedList = sortList(mItemList);
                    for (MusicItem item : sortedList) {

                        System.out.println(item.getMusicname() + item.getPlay_num() + item.getRating());
                    }
                }


//                System.out.println(data);
            }
        }catch(JSONException e){
            e.printStackTrace();
        }
        mAdapter = new ListAdapter(this, sortedList);
        mListView = (ListView) findViewById(R.id.listview1);
        mListView.setAdapter(mAdapter);

        // List item click event 처리
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> a_parent, View a_view, int a_position, long a_id) {
                final MusicItem item = (MusicItem) mAdapter.getItem(a_position);
                Toast.makeText(ListActivity.this, item.getMusicname() + " selected", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(), MusicPlayerActivity.class);
                intent.putExtra("MUSIC_NAME", item.getMusicname() );
                startActivity(intent);
            }
        });
    }
    public String readTextFile(InputStream inputStream) {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        byte buf[] = new byte[1024];
        int len;
        try {
            while ((len = inputStream.read(buf)) != -1) {
                outputStream.write(buf, 0, len);
            }
            outputStream.close();
            inputStream.close();
        } catch (IOException e) {

        }
        return outputStream.toString();
    }
}
