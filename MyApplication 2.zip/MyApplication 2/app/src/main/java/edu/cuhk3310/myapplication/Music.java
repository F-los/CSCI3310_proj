package edu.cuhk3310.myapplication;

public class Music {

    String url;
    String music_name;
    String singer;
    int rating;
    int play_num;

    public Music(String url, String music_name, String singer, int rating, int play_num){
        this.url = url;
        this.music_name =music_name;
        this.singer = singer;
        this.rating = rating;
        this.play_num = play_num;
    }
    public String getUrl(){
        return this.url;
    }
    public void setUrl(String url){
        this.url = url;
    }

    public String getMusic_name(){
        return music_name;
    }
    public void setMusic_name(String music_name){
        this.music_name = music_name;
    }

    public String getSinger(){
        return singer;
    }
    public void setSinger(String singer){
        this.singer = singer;
    }

    public int getRating(){
        return rating;
    }
    public void setRating(Integer rating){
        this.rating = rating;
    }
    public int getPlay_num(){
        return play_num;
    }
    public void setPlay_num(int play_num){
        this.play_num = play_num;
    }

}
