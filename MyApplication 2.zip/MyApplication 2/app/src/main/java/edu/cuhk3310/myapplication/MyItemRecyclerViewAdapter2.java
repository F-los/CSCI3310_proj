package edu.cuhk3310.myapplication;

import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import edu.cuhk3310.myapplication.placeholder.PlaceholderContent.PlaceholderItem;
import edu.cuhk3310.myapplication.databinding.FragmentItem2Binding;

import java.util.LinkedList;
import java.util.List;

/**
 * {@link RecyclerView.Adapter} that can display a {@link PlaceholderItem}.
 * TODO: Replace the implementation with code for your data type.
 */
public class MyItemRecyclerViewAdapter2 extends RecyclerView.Adapter<MyItemRecyclerViewAdapter2.ViewHolder> {

    private final List<Music> mMusicList;

    public MyItemRecyclerViewAdapter2(List<Music> items) {
        mMusicList = items;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        return new ViewHolder(FragmentItem2Binding.inflate(LayoutInflater.from(parent.getContext()), parent, false));

    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
//        holder.mItem = mValues.get(position);
        holder.mIdView.setText(mMusicList.get(position).music_name);
        holder.mContentView.setText(mMusicList.get(position).singer);
    }

    @Override
    public int getItemCount() {
        return mMusicList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final TextView mIdView;
        public final TextView mContentView;
        public PlaceholderItem mItem;

        public ViewHolder(FragmentItem2Binding binding) {
            super(binding.getRoot());
            mIdView = binding.itemNumber;
            mContentView = binding.content;

            // Setting click listener for the whole item view
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) { // Check if an item was deleted but the user clicked it before the UI removed it
                        Music item = mMusicList.get(position);

                        Toast.makeText(v.getContext(), item.music_name + " selected", Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(v.getContext(), MusicPlayerActivity.class);
                        // Put music name as an extra in the Intent
                        intent.putExtra("MUSIC_NAME", item.music_name);
                        // Start the MusicPlayerActivity
                        v.getContext().startActivity(intent);
                    }
                }
            });
        }

        @Override
        public String toString() {
            return super.toString() + " '" + mContentView.getText() + "'";
        }
    }
}