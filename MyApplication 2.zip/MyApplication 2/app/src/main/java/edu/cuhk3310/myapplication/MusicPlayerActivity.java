package edu.cuhk3310.myapplication;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Array;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class MusicPlayerActivity extends AppCompatActivity {

    private List<Music> music_list = new ArrayList<>();
    private List<Music> playlist = new ArrayList<>();
    private int currentMusicIndex = 0;
    String json;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.play);

        Intent intent = getIntent();
        String musicName = intent.getStringExtra("MUSIC_NAME");

        loadMusicDataFromJson();

        // find the index of the music with the given name
        currentMusicIndex = findMusicByName(musicName);
        System.out.println(currentMusicIndex);
        if (currentMusicIndex != -1) {
            updateMusicUI(currentMusicIndex);
        } else {
            // handle case where the music name is not found
            // maybe show a default view or a error message
            System.out.println("music name not found");
        }

        RatingBar musicRatingBar = (RatingBar) findViewById(R.id.ratingBar);

        Music currentMusic = music_list.get(currentMusicIndex);

        musicRatingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                // Get the current music
                Music currentMusic = music_list.get(currentMusicIndex);

                // Set the new rating value to the Music instance
                currentMusic.setRating((int) rating);

                // Save the rating and play_num to shared preferences
                SharedPreferences sharedPref = getSharedPreferences("Preferences", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putInt(currentMusic.getMusic_name() + "_rating", (int) rating);
                editor.putInt(currentMusic.getMusic_name() + "_play_num", currentMusic.getPlay_num());
                editor.apply();

                // Optionally show a message to the user
                Toast.makeText(MusicPlayerActivity.this, "New Rating: " + rating, Toast.LENGTH_SHORT).show();
            }
        });



        FloatingActionButton nextSongButton = findViewById(R.id.next);
        nextSongButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nextSong();
                System.out.println("next song");
            }
        });

        FloatingActionButton previousSongButton = findViewById(R.id.previous);
        previousSongButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                previousSong();
                System.out.println("previous song");
            }
        });

        FloatingActionButton addToPlaylistButton = findViewById(R.id.add_button);
        addToPlaylistButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addToPlaylist(v);
                System.out.println("add to playlist");
            }
        });

    }

    private void loadMusicDataFromJson() {
        InputStream XmlFileInputStream = getResources().openRawResource(R.raw.music);
        json = readTextFile(XmlFileInputStream);
        try {
            JSONObject jsonObject = new JSONObject(json);
            JSONArray musicArr = jsonObject.getJSONArray("musics");
            for (int i = 0; i < musicArr.length(); i++) {
                JSONObject musicObj = musicArr.getJSONObject(i);
                String url = musicObj.getString("url");
                String name = musicObj.getString("music_name");
                String singer = musicObj.getString("singer");
                int rating = musicObj.getInt("rating");
                int play_num = musicObj.getInt("play_num");
                Music data = new Music(url, name, singer, rating, play_num);
                music_list.add(data);
//                System.out.println(data.getMusic_name());
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void updateMusicUI(int index) {
        if (music_list != null && !music_list.isEmpty()) {
            Music music = music_list.get(index);
            TextView musicNameTextView = findViewById(R.id.music_name);
            TextView singerTextView = findViewById(R.id.singer);
            TextView playNumTextView = findViewById(R.id.play_num);
            RatingBar musicRatingBar = (RatingBar) findViewById(R.id.ratingBar);

            musicNameTextView.setText(music.getUrl());
            singerTextView.setText(music.getSinger());

            // Load rating and play_num from shared preferences
            SharedPreferences sharedPref = getSharedPreferences("Preferences", Context.MODE_PRIVATE);
            int defaultRating = sharedPref.getInt(music.getMusic_name() + "_rating", 0); // You can set this to any default value
            int play_num = sharedPref.getInt(music.getMusic_name() + "_play_num", music.getPlay_num());

            // Increment play_num and save it back to SharedPreferences
            play_num++;
            SharedPreferences.Editor editor = sharedPref.edit();
            editor.putInt(music.getMusic_name() + "_play_num", play_num);
            editor.apply();

            // Update the Music instance and UI
            music.setPlay_num(play_num);
            playNumTextView.setText(String.valueOf(play_num));

            System.out.println("Loaded rating: " + defaultRating);
            musicRatingBar.setRating(defaultRating);
        }
    }




    private void nextSong () {
            if (music_list != null && !music_list.isEmpty()) {
                currentMusicIndex = (currentMusicIndex + 1) % music_list.size();
                updateMusicUI(currentMusicIndex);
            }
        }

        private void previousSong () {
            if (music_list != null && !music_list.isEmpty()) {
                currentMusicIndex = (currentMusicIndex - 1 + music_list.size()) % music_list.size();
                updateMusicUI(currentMusicIndex);
            }
        }

        private void addToPlaylist (View v) {
            if (music_list != null && !music_list.isEmpty()) {
                Music currentMusic = music_list.get(currentMusicIndex);

                Intent intent = new Intent(v.getContext(), AddMusicActivity.class);
                // Put music name as an extra in the Intent
                intent.putExtra("MUSIC_NAME", currentMusic.music_name);
                // Start the MusicPlayerActivity
                v.getContext().startActivity(intent);
            }
        }

        private int findMusicByName (String name){
            for (int i = 0; i < music_list.size(); i++) {
                if (music_list.get(i).getMusic_name().equals(name)) {
                    return i;
                }
            }
            // Inside findMusicByName() method, before returning -1:
            System.out.println("Music with name " + name + " not found");
            return -1; // not found
        }

        public String readTextFile (InputStream inputStream){
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            byte buf[] = new byte[1024];
            int len;
            try {
                while ((len = inputStream.read(buf)) != -1) {
                    outputStream.write(buf, 0, len);
                }
                outputStream.close();
                inputStream.close();
            } catch (IOException e) {

            }
            return outputStream.toString();
    }



}
