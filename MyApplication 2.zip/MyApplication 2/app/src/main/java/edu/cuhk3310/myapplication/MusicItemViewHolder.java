package edu.cuhk3310.myapplication;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MusicItemViewHolder {
    public ImageView ivIcon;

    public TextView music_name;

    public MusicItemViewHolder(View a_view) {
        ivIcon = a_view.findViewById(R.id.iv_icon);
        music_name = a_view.findViewById(R.id.tv_country);
    }
}
