package edu.cuhk3310.myapplication;

public class PlayListItem {

    public PlayListItem(int a_imageResId, String a_musicName) {
        mImageResId = a_imageResId;
        musicName = a_musicName;
    }

    private int mImageResId;

    private String musicName;

    public void setImageResId(int a_imageResId) {
        mImageResId = a_imageResId;
    }

    public int getImageResId() {
        return mImageResId;
    }

    public void setMusicname(String a_musicname) {
        musicName = a_musicname;
    }

    public String getMusicname() {
        return musicName;
    }
}