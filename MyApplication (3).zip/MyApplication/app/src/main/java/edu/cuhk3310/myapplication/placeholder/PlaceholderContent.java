package edu.cuhk3310.myapplication.placeholder;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import edu.cuhk3310.myapplication.ItemFragment2;
import edu.cuhk3310.myapplication.R;
import edu.cuhk3310.myapplication.music_info;

/**
 * Helper class for providing sample content for user interfaces created by
 * Android template wizards.
 * <p>
 * TODO: Replace all uses of this class before publishing your app.
 */
public class PlaceholderContent {

    /**
     * An array of sample (placeholder) items.
     */
    public static final List<PlaceholderItem> ITEMS = new ArrayList<PlaceholderItem>();
    String json;
    music_info data;
    //Make flower_info data structure list
    private LinkedList<music_info> music_list= new LinkedList<>();
    /**
     * A map of sample (placeholder) items, by ID.
     */
    public static final Map<String, PlaceholderItem> ITEM_MAP = new HashMap<String, PlaceholderItem>();


    private static void addItem(PlaceholderItem item) {
        ITEMS.add(item);
        ITEM_MAP.put(item.url, item);
    }

    private static PlaceholderItem createPlaceholderItem(int position) {
        return new PlaceholderItem("123", "Item " + position, makeDetails(position), 1,2);
    }

    private static String makeDetails(int position) {
        StringBuilder builder = new StringBuilder();
        builder.append("Details about Item: ").append(position);
        for (int i = 0; i < position; i++) {
            builder.append("\nMore details information here.");
        }
        return builder.toString();
    }

    /**
     * A placeholder item representing a piece of content.
     */
    public static class PlaceholderItem {
        public final String url;
        public final String music_name;
        public final String singer;
        public final int rating;
        public final int play_num;

        public PlaceholderItem(String url, String music_name, String singer, int rating, int play_num) {
            this.url = url;
            this.music_name =  music_name;
            this.singer = singer;
            this.rating = rating;
            this.play_num = play_num;
        }

        @Override
        public String toString() {
            return singer;
        }
    }

}